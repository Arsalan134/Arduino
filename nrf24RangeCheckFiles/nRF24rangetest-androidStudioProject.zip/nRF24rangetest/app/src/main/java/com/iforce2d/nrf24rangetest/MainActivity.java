package com.iforce2d.nrf24rangetest;

import android.content.Context;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbManager;
import android.location.LocationManager;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.text.format.Time;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import android.location.Location;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;

import com.hoho.android.usbserial.driver.UsbSerialDriver;
import com.hoho.android.usbserial.driver.UsbSerialPort;
import com.hoho.android.usbserial.driver.UsbSerialProber;
import com.hoho.android.usbserial.util.HexDump;
import com.hoho.android.usbserial.util.SerialInputOutputManager;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class MainActivity extends ActionBarActivity implements GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, LocationListener {

    private static final String TAG = "nrf24";

    private static UsbSerialPort sPort = null;
    private static final int[] SERIAL_HEADER = {255,254,253,252};
    protected SerialPort mSerialPort;
    private final ExecutorService mExecutor = Executors.newSingleThreadExecutor();

    GoogleApiClient mGoogleApiClient;

    EditText nameEdit;
    TextView distanceLabel;
    TextView ppsLabel;
    TextView usbLabel;

    TextView[] bars;

    public int[] measurementCounts = new int[3000];
    public float[] measurementValues = new float[3000];

    int currentDist = 0;
    int currentPPS = 0;

    int totalReadingsTaken = 0;
    int ppstemp = 0;

    public Location homeLoc = new Location("");

    private SerialInputOutputManager mSerialIoManager;
    private final SerialInputOutputManager.Listener mListener =
            new SerialInputOutputManager.Listener() {
                @Override
                public void onRunError(Exception e) {
                    Log.d(TAG, "Runner stopped.");
                }
                @Override
                public void onNewData(final byte[] data) {
                    MainActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            MainActivity.this.updateReceivedData(data);
                        }
                    });
                }
            };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        nameEdit = (EditText)findViewById(R.id.nameEdit);
        distanceLabel = (TextView)findViewById(R.id.distanceLabel);
        ppsLabel = (TextView)findViewById(R.id.ppsLabel);
        usbLabel = (TextView)findViewById(R.id.usbLabel);

        bars = new TextView[10];
        bars[0] = (TextView)findViewById(R.id.bar0);
        bars[1] = (TextView)findViewById(R.id.bar1);
        bars[2] = (TextView)findViewById(R.id.bar2);
        bars[3] = (TextView)findViewById(R.id.bar3);
        bars[4] = (TextView)findViewById(R.id.bar4);
        bars[5] = (TextView)findViewById(R.id.bar5);
        bars[6] = (TextView)findViewById(R.id.bar6);
        bars[7] = (TextView)findViewById(R.id.bar7);
        bars[8] = (TextView)findViewById(R.id.bar8);
        bars[9] = (TextView)findViewById(R.id.bar9);

        homeLoc.setLatitude(35.615075);
        homeLoc.setLongitude(139.612631);

        for (int i = 0; i < 3000; i++) {
            measurementCounts[i] = 0;
            measurementValues[i] = 0;
        }

        buildGoogleApiClient();
        findUsbSerial();

        findViewById(android.R.id.content).setKeepScreenOn(true);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    protected synchronized void buildGoogleApiClient() {
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();
        mGoogleApiClient.connect();
    }

    @Override
    public void onConnected(Bundle connectionHint) {
        Log.d(TAG, "onConnected");
        createLocationRequest();
    }

    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {
        Log.d(TAG, "onConnectionFailed");
    }

    @Override
    public void onConnectionSuspended(int i) {
        Log.d(TAG, "onConnectionSuspended");
    }

    protected void createLocationRequest() {
        LocationRequest mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(3000);
        mLocationRequest.setFastestInterval(1000);
        mLocationRequest.setSmallestDisplacement(1);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, this);
    }

    public void onLocationChanged(Location location) {
        Log.d(TAG, "onLocationChanged " + location.toString());

        currentDist = Math.round( location.distanceTo( new Location(homeLoc) ) );

        distanceLabel.setText("Distance: " + currentDist + "m" );


    }

    public void updateBars() {
        for (int bar = 0; bar < 10; bar++) {
            int minb = bar * 100;
            int maxb = minb + 100;
            float total = 0;
            float count = 0;
            for (int i = minb; i < maxb; i++) {
                total += measurementCounts[i] * measurementValues[i];
                count += measurementCounts[i];
            }
            total /= count;
            String s = ": "+Math.round(total);
            bars[bar].setText(s);
        }
    }

    public void onSaveButton(View view) {
        Log.d(TAG, "on save button");

        String filename = nameEdit.getText().toString().trim();

        if ( filename == "" )
            return;

        FileOutputStream outputStream;

        ByteBuffer bb = ByteBuffer.allocateDirect(12000);

        try {
            outputStream = openFileOutput(filename, Context.MODE_PRIVATE);

            for (int i = 0; i < 3000; i++) {
                bb.putFloat(measurementCounts[i]);
            }
            bb.flip();
            outputStream.getChannel().write(bb);

            bb.rewind();

            for (int i = 0; i < 3000; i++) {
                bb.putFloat(measurementValues[i]);
            }
            bb.flip();
            outputStream.getChannel().write(bb);

            outputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void logConsole(String s) {
        Log.d(TAG, s);
    }

    public void findUsbSerial() {

        // Find all available drivers from attached devices.
        UsbManager manager = (UsbManager) getSystemService(Context.USB_SERVICE);
        List<UsbSerialDriver> availableDrivers = UsbSerialProber.getDefaultProber().findAllDrivers(manager);
        if (availableDrivers.isEmpty()) {
            usbLabel.setText("No UsbSerialDrivers");
            Log.d(TAG, "No UsbSerialDrivers");
            logConsole("No UsbSerialDrivers");
            return;
        }
        else {
            logConsole("" + availableDrivers.size() + " drivers");
        }

        // Open a connection to the first available driver.
        UsbSerialDriver driver = availableDrivers.get(0);
        UsbDeviceConnection connection = manager.openDevice(driver.getDevice());
        if (connection == null) {
            Log.d(TAG, "You probably need to call UsbManager.requestPermission(driver.getDevice()");
            logConsole("You probably need to call UsbManager.requestPermission(driver.getDevice()");
            return;
        }
        else {
            usbLabel.setText("Connection opened");
            logConsole("Connection opened");
        }

        // Read some data! Most have just one port (port 0).
        List<UsbSerialPort> ports = driver.getPorts();
        if (ports.isEmpty()) {
            Log.d(TAG, "No ports");
            logConsole("No ports");
            return;
        }
        else
            logConsole(""+ports.size()+" ports");

        UsbSerialPort port = ports.get(0);
        sPort = port;

        /*try {
            port.open(connection);
            port.setParameters(9600, UsbSerialPort.DATABITS_8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE);
            byte buffer[] = new byte[16];
            int totalRead = 0;
            //while (totalRead < 100) {
                int numBytesRead = port.read(buffer, 1000);
                Log.d(TAG, "Read " + numBytesRead + " bytes.");
                logConsole("Read " + numBytesRead + " bytes.");
                totalRead += numBytesRead;
            //}
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                port.close();
            }
            catch (IOException e1) {
                e1.printStackTrace();
            }
        }*/

    }

    @Override
    protected void onPause() {
        super.onPause();
        stopIoManager();
        if (sPort != null) {
            try {
                sPort.close();
            } catch (IOException e) {
// Ignore.
            }
            sPort = null;
        }
        finish();
    }
    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "Resumed, port=" + sPort);
        logConsole("Resumed, port=" + sPort);
        if (sPort == null) {
            //mTitleTextView.setText("No serial device.");
            logConsole("No serial device");
            usbLabel.setText("No serial device");
        } else {
            final UsbManager usbManager = (UsbManager) getSystemService(Context.USB_SERVICE);
            UsbDeviceConnection connection = usbManager.openDevice(sPort.getDriver().getDevice());
            if (connection == null) {
                logConsole("Opening device failed");
                usbLabel.setText("Opening device failed");
                return;
            }
            try {
                sPort.open(connection);
                sPort.setParameters(9600, UsbSerialPort.DATABITS_8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE);

                try {
                    //sendStatus();
                }
                catch (Exception e) {
                    StackTraceElement[] ste = e.getStackTrace();
                    for (int i = 0; i < ste.length; i++) {
                        logConsole( ste[i].toString() +"\n" );
                    }
                }

            } catch (IOException e) {
                usbLabel.setText("Error setting up device: "+e.getMessage());
                Log.e(TAG, "Error setting up device: " + e.getMessage(), e);
                logConsole("Error opening device: " + e.getMessage());
                try {
                    sPort.close();
                } catch (IOException e2) {
// Ignore.
                }
                sPort = null;
                return;
            }
            logConsole("Serial device: " + sPort.getClass().getSimpleName());
            usbLabel.setText("Serial device: "+sPort.getClass().getSimpleName());
        }
        onDeviceStateChange();
    }
    private void stopIoManager() {
        if (mSerialIoManager != null) {
            Log.i(TAG, "Stopping io manager ..");
            logConsole("Stopping io manager ..\n");
            mSerialIoManager.stop();
            mSerialIoManager = null;
        }
    }
    private void startIoManager() {
        if (sPort != null) {
            Log.i(TAG, "Starting io manager ..");
            logConsole("Starting io manager ..\n");
            mSerialIoManager = new SerialInputOutputManager(sPort, mListener);
            mExecutor.submit(mSerialIoManager);

            try {
                //sendStatus();
            }
            catch (Exception e) {
                StackTraceElement[] ste = e.getStackTrace();
                for (int i = 0; i < ste.length; i++) {
                    logConsole( ste[i].toString() +"\n" );
                }
            }
        }
    }
    private void onDeviceStateChange() {
        stopIoManager();
        startIoManager();
    }

    int currentBytePos = 0;

    private void processRXByte(int b) {
        //logConsole("p "+currentBytePos+" b "+b);
        switch ( currentBytePos ) {
            case 0: if (b == SERIAL_HEADER[0]) currentBytePos++; break;
            case 1: if (b == SERIAL_HEADER[1]) currentBytePos++; break;
            case 2: if (b == SERIAL_HEADER[2]) currentBytePos++; break;
            case 3: if (b == SERIAL_HEADER[3]) currentBytePos++; break;

            case 4: ppstemp = b; currentBytePos++; break;
            case 5: ppstemp |= (b<<8); currentPPS = ppstemp;; currentBytePos++; updateCurrentPPS(); break;
        }

        if ( currentBytePos == 6 )
            currentBytePos = 0;
    }

    private void updateReceivedData(byte[] data) {

        for (int i = 0; i < data.length; i++) {
            processRXByte( (int) data[i] & 0xff );
        }

    }

    void updateCurrentPPS() {

        ppsLabel.setText( "PPS: "+currentPPS );

        if ( currentDist > 0 )
            updateMeasurements();
    }

    void updateMeasurements() {

        totalReadingsTaken++;

        if ( totalReadingsTaken < 5 ) { // wait 5 seconds for arduino to start giving valid values
            return;
        }

        float oldVal = measurementValues[currentDist];
        int oldCount = measurementCounts[currentDist];

        int newCount = oldCount + 1;
        float newVal = (oldVal * oldCount + currentPPS) / (float)newCount;

        measurementCounts[currentDist] = newCount;
        measurementValues[currentDist] = newVal;

        updateBars();
    }
}
